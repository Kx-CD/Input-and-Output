# Mathematica Input & Output

A static GitHub Pages website for the `KS MATHS(2).pdf` material.

## Features
- Searchable OCR text
- Copy buttons
- Copy Page Text
- Dark/Light mode
- Mobile responsive
- Source page images for visual verification
- No backend or npm required

## GitHub Pages
1. Upload all files in this folder to the repository root.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/ (root)**.
5. Save and wait for GitHub Pages to publish.

The site is designed as a static HTML/CSS/JavaScript project.
