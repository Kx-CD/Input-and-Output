
const search = document.getElementById("search");
const cards = [...document.querySelectorAll(".card")];
const pages = [...document.querySelectorAll(".page-section")];
const count = document.getElementById("count");
const themeBtn = document.getElementById("themeBtn");

function updateCount(){
  const q = search.value.trim().toLowerCase();
  let shown = 0;
  cards.forEach(card=>{
    const match = !q || card.dataset.search.includes(q);
    card.classList.toggle("hidden", !match);
    if(match) shown++;
  });
  pages.forEach(page=>{
    const text = page.innerText.toLowerCase();
    page.classList.toggle("hidden", !!q && !text.includes(q));
  });
  count.textContent = q ? `${shown} matching example${shown===1?"":"s"}` : `${cards.length} examples`;
}
search.addEventListener("input", updateCount);

async function copyCode(id, button){
  const el = document.getElementById(id);
  const text = el ? el.innerText : "";
  try{
    await navigator.clipboard.writeText(text);
    const old = button.textContent;
    button.textContent = "Copied!";
    setTimeout(()=>button.textContent=old,1200);
  }catch(e){
    const ta=document.createElement("textarea");
    ta.value=text; document.body.appendChild(ta); ta.select();
    document.execCommand("copy"); ta.remove();
    button.textContent="Copied!";
    setTimeout(()=>button.textContent="Copy",1200);
  }
}
document.querySelectorAll("[data-copy]").forEach(btn=>{
  btn.addEventListener("click",()=>copyCode(btn.dataset.copy,btn));
});

themeBtn.addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  themeBtn.textContent=document.body.classList.contains("dark")?"Light mode":"Dark mode";
});
updateCount();
